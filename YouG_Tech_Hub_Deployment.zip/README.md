
YouG Tech Hub Deployment Package

1. Install Docker and Docker Compose
2. Copy .env.example to .env
3. Update secrets
4. Run:

chmod +x deploy.sh
./deploy.sh

Application:
- Frontend: http://localhost:3000
- Backend: http://localhost:5000
